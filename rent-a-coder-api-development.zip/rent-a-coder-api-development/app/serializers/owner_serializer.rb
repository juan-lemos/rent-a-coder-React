class OwnerSerializer < ActiveModel::Serializer
  attributes :name, :owner_score
end
