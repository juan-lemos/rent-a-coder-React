class CandidateSerializer < ActiveModel::Serializer
  attributes :id, :name, :developer_score
end
