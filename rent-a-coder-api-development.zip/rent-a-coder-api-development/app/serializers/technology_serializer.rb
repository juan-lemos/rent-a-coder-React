class TechnologySerializer < ActiveModel::Serializer
  attributes :id, :name
end
